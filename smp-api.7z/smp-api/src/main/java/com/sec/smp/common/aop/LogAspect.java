package com.sec.smp.common.aop;

import lombok.extern.log4j.Log4j2;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.MDC;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Aspect
@Component
@Configuration
@Log4j2
public class LogAspect {

    private static final String REF_ID = "xApiId";

    @Before("execution(* com.sec.smp.rest.*.controller..*.*(..))")
    public void mdcPut(JoinPoint joinPoint) {
        //to get method name
        log.info("added mdc key before calling "+joinPoint.getSignature().getName()+"()");

        //to get method args
        Object[] methodArgs = joinPoint.getArgs();
        for (Object oneArg: methodArgs) {
            System.out.println("arg="+oneArg);
        }

        MDC.put(REF_ID, UUID.randomUUID().toString().replace("-", "").substring(0, 12));
    }

    @After("execution(* com.sec.smp.rest.*.controller..*.*(..))")
    public void mdcRemove(JoinPoint joinPoint) {
        log.info("removed mdc key after calling "+joinPoint.getSignature().getName()+"()");
        MDC.remove(REF_ID);
    }
}

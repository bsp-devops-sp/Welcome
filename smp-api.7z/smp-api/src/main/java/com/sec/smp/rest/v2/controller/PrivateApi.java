package com.sec.smp.rest.v2.controller;

import com.sec.smp.biz.service.AccountService;
import com.sec.smp.rest.v2.payload.UserResponse;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "private", description = "user")
@RequiredArgsConstructor
@RestController
@RequestMapping(value = "/v2")
@Log4j2
@SecurityScheme(
        name = "Bearer Authentication",
        type = SecuritySchemeType.HTTP,
        bearerFormat = "JWT",
        scheme = "bearer"
)
public class PrivateApi {
    private final AccountService userService;

    @SecurityRequirement(name = "Bearer Authentication")
    @GetMapping("/users")
    public ResponseEntity<List<UserResponse>> userList() {
        return ResponseEntity.ok().body(userService.findAll());
    }
}

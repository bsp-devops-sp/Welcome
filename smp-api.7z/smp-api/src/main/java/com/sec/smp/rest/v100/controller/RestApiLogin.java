package com.sec.smp.rest.v100.controller;

import com.sec.smp.biz.service.AccountService;
import com.sec.smp.rest.v100.payload.AuthenticationResponse;
import com.sec.smp.rest.v100.payload.SignUpRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "회원", description = "회원관리")
@RequiredArgsConstructor
@RestController
@RequestMapping(value = "/v100")
@Log4j2
public class RestApiLogin {

    final AccountService accountService;

    @Operation(summary = "회원등록", description = "토큰생성")
    @PostMapping("/signUp")
    public ResponseEntity<AuthenticationResponse> signUp( @Valid @RequestBody SignUpRequest request) {
        return ResponseEntity.ok(accountService.signUp(request));
    }


    @Operation(summary = "리프레쉬 토큰생성", description = "토큰생성")
    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@Valid @RequestBody  SignUpRequest request) {
        return ResponseEntity.ok().body("추가 구현 필요");
    }
}

package com.sec.smp.common.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.sec.smp.biz.domain.LoginUser;
import com.sec.smp.biz.domain.User;
import com.sec.smp.biz.domain.UserRole;
import com.sec.smp.rest.v100.payload.AuthenticationResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;


@Component
public class JwtUtils {

    private static String secret;

    @Autowired
    public void setString(@Value("${jwt.secret}") String secret) {
        this.secret = secret;
    }
    private static final Logger log = LoggerFactory.getLogger(JwtUtils.class);

    private static long EXPIRATION_TIME = 1000 * 60 * 24;

    public static AuthenticationResponse generateToken(LoginUser loginUser) {
        String accessToken = JWT.create()
                .withSubject(loginUser.getUsername())
                .withExpiresAt(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .withClaim("email", loginUser.getUsername())
                .withClaim("role", UserRole.USER.name())
                .sign(Algorithm.HMAC512(secret));
        // Refresh Token 생성
        String refreshToken = JWT.create()
                .withExpiresAt(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .sign(Algorithm.HMAC512(secret));
        return AuthenticationResponse
                .builder()
                .refreshToken(refreshToken)
                .accessToken(accessToken)
                .build();
    }

    public static LoginUser verify(String token) {
        log.debug("디버그 : JwtProcess verify()");
        DecodedJWT decodedJWT = JWT.require(Algorithm.HMAC512(secret)).build().verify(token);
        String email = decodedJWT.getClaim("email").asString();
        String role = decodedJWT.getClaim("role").asString();
        User user = User.builder().email(email).role(role).build();
        LoginUser loginUser = new LoginUser(user);
        return loginUser;
    }
}

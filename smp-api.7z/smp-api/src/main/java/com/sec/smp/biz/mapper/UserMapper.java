package com.sec.smp.biz.mapper;


import com.sec.smp.biz.domain.User;

import java.util.List;
import java.util.Optional;

public interface UserMapper {

    Optional<User> findByEmail(String email);

    List<User> findAll();

    void insertUser(User u);

}

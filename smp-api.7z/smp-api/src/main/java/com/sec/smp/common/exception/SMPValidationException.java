package com.sec.smp.common.exception;

import java.util.Map;

public class SMPValidationException extends RuntimeException {

    private Map<String, String> errorMap;

    public SMPValidationException(String message, Map<String, String> errorMap) {
        super(message);
        this.errorMap = errorMap;
    }

    public Map<String, String> getErrorMap() {
        return errorMap;
    }
}

package com.sec.smp.biz.service;

import com.sec.smp.biz.domain.LoginUser;
import com.sec.smp.biz.domain.User;
import com.sec.smp.biz.domain.UserRole;
import com.sec.smp.biz.mapper.UserMapper;
import com.sec.smp.common.utils.JwtUtils;
import com.sec.smp.rest.v100.payload.AuthenticationResponse;
import com.sec.smp.rest.v100.payload.SignUpRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class AuthenticationService {
    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;

    private final AuthenticationManager authenticationManager;

    public AuthenticationResponse register(SignUpRequest request) {
        var user = User.builder()
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(UserRole.USER.name())
                .build();
        userMapper.insertUser(user);
        AuthenticationResponse authenticationResponse = JwtUtils.generateToken(new LoginUser(user));
        return authenticationResponse;
    }

}

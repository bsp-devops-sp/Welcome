package com.sec.smp.biz.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class User {

    Integer id;
    String email;
    String password;
    String role;

}


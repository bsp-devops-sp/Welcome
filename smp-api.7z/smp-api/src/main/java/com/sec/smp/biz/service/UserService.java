package com.sec.smp.biz.service;

import com.sec.smp.biz.mapper.UserMapper;
import com.sec.smp.rest.v2.payload.UserResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserMapper userMapper;

    public List<UserResponse> findAll() {
        return userMapper.findAll().stream()
                .map(user -> new UserResponse(user))
                .collect(Collectors.toList());
    }

}

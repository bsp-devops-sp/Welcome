package com.sec.smp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SMPApplication {

    public static void main(String[] args) {
        SpringApplication.run(SMPApplication.class, args);
    }

}

package com.sec.smp.rest.v100.payload;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

// http code = 200(get, delete, put), 201(post)
@RequiredArgsConstructor
@Getter
public class CommonResponse<T> {
    private final HttpStatus httpStatus; // 1 성공, -1 실패, 99 관리자 성공, -99 관리자 실패
    private final String message;
    private final T data;
}

package com.sec.smp.biz.service;

import com.sec.smp.biz.domain.LoginUser;
import com.sec.smp.biz.domain.User;
import com.sec.smp.biz.domain.UserRole;
import com.sec.smp.biz.mapper.UserMapper;
import com.sec.smp.common.utils.JwtUtils;
import com.sec.smp.rest.v100.payload.AuthenticationResponse;
import com.sec.smp.rest.v100.payload.SignUpRequest;
import com.sec.smp.rest.v2.payload.UserResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class AccountService {
    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;

    private final AuthenticationManager authenticationManager;
    @Transactional(readOnly = true)
    public List<UserResponse> findAll() {
        return userMapper.findAll().stream()
                .map(user -> new UserResponse(user))
                .collect(Collectors.toList());
    }

    @Transactional
    public AuthenticationResponse signUp(SignUpRequest request) {
        var user = User.builder()
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(UserRole.USER.name())
                .build();
        userMapper.insertUser(user);
        var authenticationResponse = JwtUtils.generateToken(new LoginUser(user));
        return AuthenticationResponse.builder()
                .accessToken(authenticationResponse.getAccessToken())
                .refreshToken(authenticationResponse.getRefreshToken())
                .build();
    }
}

package com.sec.smp.biz.domain;

public enum UserRole {
    USER,
    ADMIN
}

package com.sec.smp.rest.v2.payload;

import com.sec.smp.biz.domain.User;
import lombok.Data;

@Data
public class UserResponse {

    public UserResponse(User user) {
        this.id = user.getId();
        this.email = user.getEmail();
        this.role = user.getRole();

    }
    Integer id;
    String email;
    String role;

}

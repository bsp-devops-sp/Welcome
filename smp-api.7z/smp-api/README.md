# smp-api

1. Srpinb boot 3 (OpenJDK 17)
2. spring security 6 + jwt
3. gradle
4. mybatis
5. jdbc datasource
6. Lombok
7. Log4j2
8. swagger

### jdk 17 설치 필수 입니다.

### 위 환경만 기본 구성 되었고 각 정책에 맞게 공통 재구성 필요


spring 기동후
localhost:8080 접속시 swagger api 로 이동됩니다.

